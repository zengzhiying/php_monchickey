<?php
header('Content-Type:text/html; charset=utf-8');
echo '这是重定向后的新页面';
?>